
import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [shipment, setShipment] = useState(null);

  const trackShipment = async () => {
    try {
      const res = await axios.get(`https://aero-parcel-backend0.onrender.com/track/${trackingNumber}`);
      setShipment(res.data);
    } catch (err) {
      setShipment({ error: 'Shipment not found' });
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>AERO PARCEL Tracking</h1>
      <input type="text" value={trackingNumber} onChange={(e) => setTrackingNumber(e.target.value)} placeholder="Enter tracking number" />
      <button onClick={trackShipment}>Track</button>
      <div style={{ marginTop: '20px' }}>
        {shipment && <pre>{JSON.stringify(shipment, null, 2)}</pre>}
      </div>
    </div>
  );
}

export default App;
